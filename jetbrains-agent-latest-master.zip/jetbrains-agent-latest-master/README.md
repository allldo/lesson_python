# jetbrains-agent-latest
Intellij IDEA License Activation

**1** - Download IntelliJ (or any jetbrains ide) from the official site.\
**2** - Install with evaluation license.\
**3** - On the welcome screen, drag-and-drop the jetbrains-agent-latest.zip file.\
**4** - Restart IntelliJ\
**5** - When starting, an jetbrains-agent window is shown (see image). Enter the key below.
NOTE! The key has been changed to work.
```
f9fF1I/ygZI7Ff14sigGMZmZ7KJkhsM364o6exiukAqGORVXN1e4Fk4B8+hGSl5B+iLp9nIA2pSNhNGlxnDgSV3xC85CGVvWY9SWa+ECeWhJZ1+hitDPCNw5lKaRBnxIKhAfQ3aJl4S5WmrOkfKoIuz3UXVoX7hZGxofqQtzfuc
```
![](https://www.linkpicture.com/q/install-explain_2020.2.1.jpg)\
**6** - Click 'Install for IDEA' button and restart the IDE.\
**7** - Done!
